﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    internal class First_N_Prime_Numbers
    {
        static void Main()
        {
            Console.Write("Enter the value of N: ");
            int n = int.Parse(Console.ReadLine());

            int count = 0, num = 2;

            while (count < n)
            {
                if (IsPrime(num))
                {
                    Console.Write(num + " ");
                    count++;
                }
                num++;
            }
        }

        static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }
    }
}
