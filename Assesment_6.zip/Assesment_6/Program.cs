﻿namespace Assesment_6
{
  
        internal class Program
        {
            static void Main(string[] args)
            {
                Random random = new Random();
                int min = 1, max = 100;
                int numberToGuess = random.Next(min, max + 1);
                int attempts = 5;
                int userGuess = 0;

                Console.WriteLine($"Guess the number between {min} and {max}. You have {attempts} attempts.");

                while (attempts > 0)
                {
                    Console.Write("Enter your guess: ");
                    if (int.TryParse(Console.ReadLine(), out userGuess))
                    {
                        if (userGuess == numberToGuess)
                        {
                            Console.WriteLine("Congratulations! You guessed the number correctly.");
                            break;
                        }
                        else if (userGuess > numberToGuess)
                        {
                            Console.WriteLine("Too high!");
                        }
                        else
                        {
                            Console.WriteLine("Too low!");
                        }
                        attempts--;
                        Console.WriteLine($"Attempts remaining: {attempts}");
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid number.");
                    }
                }

                if (attempts == 0)
                {
                    Console.WriteLine($"Sorry, you've run out of attempts. The correct number was {numberToGuess}.");
                }
            }
        }

    }

