class Book {
    // Method to set properties
    setDetails(title, author, publicationYear) {
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
    }

    // Method to display book details
    displayDetails() {
        console.log(`Title: ${this.title}, Author: ${this.author}, Year: ${this.publicationYear}`);
    }
}

// Creating an instance of Book and setting details
const book = new Book();
book.setDetails("Kalki", "NagAswin", 2024);
book.displayDetails();
