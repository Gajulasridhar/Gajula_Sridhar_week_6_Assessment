﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    internal class ArrayOperations
    {
      


        static void Main()
        {
            int[] numbers = { 4, 8, 15, 16, 23, 42 };

            int sum = 0;
            int max = numbers[0];
            int min = numbers[0];

            foreach (int num in numbers)
            {
                sum += num;
                if (num > max)
                    max = num;
                if (num < min)
                    min = num;
            }

            double average = (double)sum / numbers.Length;

            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Average: {average}");
            Console.WriteLine($"Max: {max}");
            Console.WriteLine($"Min: {min}");
        }
    }

}

