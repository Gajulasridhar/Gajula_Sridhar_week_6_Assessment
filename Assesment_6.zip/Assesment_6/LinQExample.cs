﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }

    class Enrollment
    {
        public int StudentID { get; set; }
        public string Course { get; set; }
    }

    class LinQExample
    {
        static void Main()
        {
            List<Student> students = new List<Student>
        {
            new Student { ID = 1, Name = "sridhar" },
            new Student { ID = 2, Name = "sai" },
            new Student { ID = 3, Name = "srivastav" }
        };

            List<Enrollment> enrollments = new List<Enrollment>
        {
            new Enrollment { StudentID = 1, Course = "Math" },
            new Enrollment { StudentID = 2, Course = "Science" },
            new Enrollment { StudentID = 1, Course = "History" },
            new Enrollment { StudentID = 3, Course = "English" }
        };

            var studentCourses = from student in students
                                 join enrollment in enrollments
                                 on student.ID equals enrollment.StudentID
                                 select new { student.Name, enrollment.Course };

            foreach (var sc in studentCourses)
            {
                Console.WriteLine($"{sc.Name} is enrolled in {sc.Course}");
            }
        }
    }
    
}
